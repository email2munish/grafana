// Libraries
import React from 'react';
import { css, cx } from 'emotion';

// Utils & Services
import { config } from 'app/core/config';

// Components
import { setFooterLinksFn, FooterLink } from 'app/core/components/Footer/Footer';
import { Branding, BrandComponentProps } from 'app/core/components/Branding/Branding';

interface WhitelabelingSettings {
  links: FooterLink[];
  appTitle: string;
  loginLogo: string;
  loginBackground: string;
  menuLogo: string;
}

export function initWhitelabeling() {
  const settings = (config as any).whitelabeling as WhitelabelingSettings;

  if (!settings) {
    return;
  }

  if (settings.links.length > 0) {
    setFooterLinksFn(() => {
      return settings.links.map(link => ({ ...link, target: '_blank' }));
    });
  }

  if (settings.appTitle) {
    Branding.AppTitle = settings.appTitle;
  }

  if (settings.loginLogo) {
    Branding.LoginLogo = (props: BrandComponentProps) => <img className={props.className} src={settings.loginLogo} />;
  }

  if (settings.menuLogo) {
    Branding.MenuLogo = (props: BrandComponentProps) => <img className={props.className} src={settings.menuLogo} />;
  }

  if (settings.loginBackground) {
    const background = css`
      background: ${settings.loginBackground};
      background-size: cover;
    `;

    Branding.LoginBackground = (props: BrandComponentProps) => (
      <div className={cx(background, props.className)}>{props.children}</div>
    );
  }
}
