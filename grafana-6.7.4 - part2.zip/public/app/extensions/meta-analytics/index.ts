import { registerEchoBackend } from '@grafana/runtime';
import { MetaAnalyticsBackend } from './MetaAnalyticsBackend';

export const initMetaAnalytics = () => {
  registerEchoBackend(new MetaAnalyticsBackend({ url: '/api/ma/events' }));
};
