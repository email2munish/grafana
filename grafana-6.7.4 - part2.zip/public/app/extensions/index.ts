import { addRouteRegistrationHandler } from 'app/routes/registry';
import LicensePage from './licensing/LicensePage';
import ReportsList from './reports/ReportsListPage';
import ReportPage from './reports/ReportPage';
import reportsReducers from './reports/state/reducers';
import { initReporting } from './reports';
import DataSourcePermissions from './permissions/DataSourcePermissions';
import { addRootReducer } from 'app/store/configureStore';
import dataSourcePermissionReducers from './permissions/state/reducers';
import { initWhitelabeling } from './whitelabeling';
import { initMetaAnalytics } from './meta-analytics';
import { config } from 'app/core/config';
import { initLicenseWarnings } from './licensing';

function initEnterprise() {
  addRootReducer({ ...dataSourcePermissionReducers, ...reportsReducers });

  initWhitelabeling();
  initLicenseWarnings();
  initReporting();

  addRouteRegistrationHandler($routeProvider => {
    initMetaAnalytics();

    $routeProvider
      .when('/datasources/edit/:id/permissions', {
        template: '<react-container />',
        resolve: {
          component: () => DataSourcePermissions,
        },
      })
      .when('/reports', {
        template: '<react-container />',
        resolve: {
          component: () => ReportsList,
        },
      })
      .when('/reports/new', {
        template: '<react-container />',
        resolve: {
          component: () => ReportPage,
        },
      })
      .when('/reports/edit/:id', {
        template: '<react-container />',
        resolve: {
          component: () => ReportPage,
        },
      });
  });
}

// initUnlicensed initialized features which are defined in Enterprise but
// should be available when running without a license.
function initUnlicensed() {
  addRouteRegistrationHandler($routeProvider => {
    initMetaAnalytics();

    $routeProvider.when('/admin/licensing', {
      template: '<react-container />',
      resolve: {
        roles: () => ['Admin'],
        component: () => LicensePage,
      },
    });
  });
}

initUnlicensed();
if (config.licenseInfo.hasLicense) {
  initEnterprise();
}
