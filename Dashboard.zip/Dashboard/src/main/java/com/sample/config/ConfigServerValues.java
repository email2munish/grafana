package com.sample.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
//import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;


@Component
//@RefreshScope
public class ConfigServerValues {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigServerValues.class);

	
	@Value("${app.edt.serviceurl}")
	private String edtServiceUrl;


	public String getEdtServiceUrl() {
		return edtServiceUrl;
	}

}
