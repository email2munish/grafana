package com.sample.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sample.service.MessageService;
 
@RestController
public class DataJobController {
 
 @Autowired
 MessageService messageService;
 
  @RequestMapping("/insertdata")
  public String handle() throws Exception {
 
    Logger logger = LoggerFactory.getLogger(this.getClass());
    try {
    	messageService.insertDataRow();
    	
    } catch (Exception e) {
      logger.info(e.getMessage());
    }
 
    return "Done";
  }
}