package com.sample.controller;

public class Invoke {
	
	public static void main(String[] args) {
		new Invoke();
	}

}
