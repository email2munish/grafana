package com.sample.mediator;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.sample.common.Constants;
import com.sample.common.DashBoardException;
import com.sample.common.RunTimeUtil;
import com.sample.config.ConfigServerValues;
import com.sample.model.ElkResponse;

@Component
public class ServiceMediator {

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceMediator.class);

	@Autowired
	ConfigServerValues configServerValues;

	/*
	 * RestClient restClient = RestClient.builder( new
	 * HttpHost("c0009571.test.cloud.fedex.com", 9200, "http")).build();
	 */
	RestClient restClient = RestClient.builder(
		       new HttpHost("localhost", 9200, "http")).build();

	
	@Retryable(value = { DashBoardException.class }, maxAttemptsExpression = "${app.edt.retry-attempts-ml-service}")
	public ElkResponse callEdtMaaSService(String request) throws DashBoardException {

		LOGGER.trace(Constants.START_OF_METHOD);
		long startTime = System.nanoTime();
		ElkResponse edtResponse = null;

		try {
			
				HttpEntity entity1 = new NStringEntity(request,ContentType.APPLICATION_JSON);
				Map<String, String> paramMap = new HashMap<String, String>();
				paramMap.put("pretty", "true");
				Request elk_request = new Request("POST",  configServerValues.getEdtServiceUrl());
				elk_request.addParameter("pretty", "true");
				elk_request.setEntity(entity1);
				Response response = restClient.performRequest(elk_request);
				
				System.out.println(EntityUtils.toString(response.getEntity()));
				System.out.println("Host -" + response.getHost() );
				System.out.println("RequestLine -"+ response.getRequestLine() );
		} catch (RestClientException restClientException) {
			LOGGER.error("Unable to connect Service : callEdtMaaSService "
					+ ExceptionUtils.getStackTrace(restClientException));
			throw new DashBoardException(Constants.EDT_SYSTEM_ER_CODE, Constants.EDT_SYSTEM_ER_MSG);
		} catch (Exception restClientException) {
			LOGGER.error("Unable to connect Service : callEdtMaaSService "
					+ ExceptionUtils.getStackTrace(restClientException));
			throw new DashBoardException(Constants.EDT_SYSTEM_ER_CODE, Constants.EDT_SYSTEM_ER_MSG);
		} 
		LOGGER.trace(Constants.END_OF_METHOD);
		
		return edtResponse;
	}
	
	private HttpHeaders getHttpHeaders() {
		
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		//httpHeaders.set("Authorization", configServerValues.getSecurityKey());
		return httpHeaders;
	}

	private static String stubResponse(long delay) {
		try {
			Thread.sleep(delay);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return "{\"edtw1_left\": \"10:30\", \"edtw1_right\": \"17:18\"}";
	}

}
