package com.sample.service;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.NDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sample.common.Constants;
import com.sample.common.DashBoardException;
import com.sample.common.RunTimeUtil;
import com.sample.mediator.ServiceMediator;
import com.sample.model.DevOpsDto;
import com.sample.model.DevOpsDtoGen;
import com.sample.model.DevOpsDtoGen13;
import com.sample.model.ElkResponse;

@Component
public class MessageService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageService.class);

	@Autowired
	ServiceMediator serviceMediator;
	
	@Autowired
	RunTimeUtil runTimeUtil;
	
	@Autowired
	DevOpsDtoGen13 devOpsDtoGen13;
	
	@Autowired
	DevOpsDtoGen devOpsDtoGen;

	ObjectMapper mapper;

	public MessageService() {
	    mapper = new ObjectMapper();
	}

	

	public void insertDataRow() {
		
		NDC.push(runTimeUtil.createNDCMessage());
		long startTime = System.nanoTime();

		LOGGER.info(Constants.START_OF_METHOD);
		
		ElkResponse payload = null;
		String json =  null;
		try {
			for(int count = 2 ; count < 101 ; count ++) {
				//json = mapper.writeValueAsString(devOpsDtoGen.genObj(count,"HsValidationService"));
				//json = mapper.writeValueAsString(devOpsDtoGen13.genObj(count,"EdtDetailLookUpService"));
				//json = mapper.writeValueAsString(devOpsDtoGen.genObj(count,"HsSearchService"));
				//json = mapper.writeValueAsString(devOpsDtoGen13.genObj(count,"HsSearchService"));
				//json = mapper.writeValueAsString(devOpsDtoGen13.genObj(count,"EdtDetailLookUpService"));
				json = mapper.writeValueAsString(devOpsDtoGen13.genObj(count,"HsValidationService"));
				
				LOGGER.info("DevRequest: " + json);
				payload = serviceMediator.callEdtMaaSService(json);
				LOGGER.info("DevResponse: " + payload);
				
			}

			runTimeUtil.logRunTimeInfo(startTime, Constants.METHOD_SERVICE);
		} 
		/*
		 * catch (DashBoardException e) { // If Any exception store the message in
		 * failure queue. LOGGER.info("Alert !!! Inserting Message in failure_queue");
		 * LOGGER.error("Server Exception in handling Request : "+
		 * ExceptionUtils.getStackTrace(e)); }
		 */		catch (Exception e) {
			// If Any exception store the message in failure queue.
			LOGGER.info("Alert !!! Inserting Message in failure_queue");
			LOGGER.error("Server Exception in handling Request : "+ ExceptionUtils.getStackTrace(e));
		}
		finally {
			LOGGER.info(Constants.END_OF_METHOD);
			NDC.pop();
		}
		//return payload;
	}
}