package com.sample.model;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class DevOpsDtoGen13 {
	
	//static String pattern = "yyyy-MM-dd.HH-mm-ss";
	static String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSSSSZ";
	static DateTimeFormatter oldPattern = DateTimeFormatter.ofPattern(pattern);
	
	
	public DashBoardVo genObj(int count, String servicenName) {
		DashBoardVo dto =  new DashBoardVo();
		dto.setServiceName(servicenName);
		dto.setEai(3531590);
		dto.setDomain("HsServices");
		//dto.setDomain("EdtServices");
		dto.setStartedBy("Pravin Parbat (OSV)");
		dto.setIsLoadMaster("Pravin Parbat (OSV)");
		dto.setBuildNumber(count);
		dto.setBuildType("CI");
		dto.setEnvironment("L1");
		dto.setArtifact(servicenName+"-2020.6."+count);
		ZonedDateTime tomorrow = ZonedDateTime.now().minusDays(100).plusDays(count);
		dto.setTimestamp(tomorrow.format(oldPattern));
		dto.setFindMergeRequests("false");
		dto.setBranch(servicenName+"-1.0-RELEASE");
		dto.setRevision("777c11f4ec269508fb974ab72831a325e40b9b2a"+count);
		dto.setBuild("SUCCESS");
		dto.setProjectKey(servicenName+"-3531592");
		dto.setSonarProjUrl("https://sonar.prod.cloud.fedex.com:9443/dashboard?id=edtdetaillookupservice-3531590");
		dto.setSonarUrl("https://sonar.prod.cloud.fedex.com:9443");
		dto.setNexusUrl("https://nexus.prod.cloud.fedex.com:8443/nexus/repository/");
		dto.setQualityGate("PASS");
		dto.setNcloc(3442 + count);
		dto.setComplexity(count+234);
		dto.setBugs(getRandomNumberInRange(count, count+1));
		dto.setNewBugs(getRandomNumberInRange(count, count+1));
		dto.setVulnerabilities(getRandomNumberInRange(count, count+5));
		dto.setNewVulnerabilities(getRandomNumberInRange(count, count+1));
		dto.setSMELLDEBT(getRandomNumberInRange(count, count+4));
		dto.setNewTechnicalDebt(getRandomNumberInRange(count, count+1));
		dto.setCodeSmell(getRandomNumberInRange(count, count+8));
		dto.setNewCodeSmell(getRandomNumberInRange(count, count+1));
		dto.setDuplicatedLinesDensity(new Double(count+20));
		dto.setDuplicatedBlocks(getRandomNumberInRange(count, count+9));
		dto.setNewDuplicatedBlocks(getRandomNumberInRange(count, count+1));
		dto.setCoverage(20d);
		dto.setFortifyTotal(count*4);
		dto.setFortifyCritical(count + 2);
		dto.setFortifyHigh(count);
		dto.setFortifyLow(count+1);
		dto.setFortifyMedium(dto.getFortifyTotal()-(dto.getFortifyCritical()+dto.getFortifyHigh()+dto.getFortifyLow()));
		dto.setL1Env("L1");
		dto.setL1StartedBy("Mayur Gaikur");
		dto.setL1LoadMaster("Mayur Gaikur");
		dto.setL1BuildNumber(count+5);
		dto.setL1Timestamp(tomorrow.format(oldPattern));
		dto.setL1DeployStatus("SUCCESS");
		dto.setL1TestStatus("PASS");
		dto.setL1Approval("Pravin Parbat (OSV)");
		dto.setL1Deployment("Pravin Parbat (OSV)");
		dto.setL1TestPass(15);
		dto.setL1TestFail(3);
		dto.setL1TestNotrun(2);
		dto.setL1TestTotal(20);
		dto.setL1AvgResponseTime(85);
		dto.setL2Env("L2");
		dto.setL2StartedBy("Mayur Gaikur");
		dto.setL2LoadMaster("Mayur Gaikur");
		dto.setL2BuildNumber(count+6);
		dto.setL2Timestamp(tomorrow.format(oldPattern));
		dto.setL2DeployStatus("SUCCESS");
		dto.setL2TestStatus("FAIL");
		dto.setL2Approval("Pravin Parbat (OSV)");
		dto.setL2Deployment("Pravin Parbat (OSV)");
		dto.setL2TestPass(7);
		dto.setL2TestFail(2);
		dto.setL2TestNotrun(1);
		dto.setL2TestTotal(10);
		dto.setL2AvgResponseTime(120);
		dto.setL3Env("L3");
		dto.setL3StartedBy("Mayur Gaikur");
		dto.setL3LoadMaster("Mayur Gaikur");
		dto.setL3BuildNumber(count+7);
		dto.setL3Timestamp(tomorrow.format(oldPattern));
		dto.setL3DeployStatus("SUCCESS");
		dto.setL3TestStatus("FAIL");
		dto.setL3Approval("Pravin Parbat (OSV)");
		dto.setL3Deployment("Pravin Parbat (OSV)");
		dto.setL3TestPass(5);
		dto.setL3TestFail(3);
		dto.setL3TestNotrun(2);
		dto.setL3TestTotal(10);
		dto.setL3AvgResponseTime(119);
		dto.setL4Env("L4");
		dto.setL4StartedBy("Mayur Gaikur");
		dto.setL4LoadMaster("Mayur Gaikur");
		dto.setL4BuildNumber(count+9);
		dto.setL4Timestamp(tomorrow.format(oldPattern));
		dto.setL4DeployStatus("SUCCESS");
		dto.setL4TestStatus("PASS");
		dto.setL4Approval("Pravin Parbat (OSV)");
		dto.setL4Deployment("Pravin Parbat (OSV)");
		dto.setL4TestPass(7);
		dto.setL4TestFail(2);
		dto.setL4TestNotrun(1);
		dto.setL4TestTotal(10);
		dto.setL4AvgResponseTime(65);
		dto.setL6Env("L6");
		dto.setL6StartedBy("Mayur Gaikur");
		dto.setL6LoadMaster("Mayur Gaikur");
		dto.setL6BuildNumber(count+12);
		dto.setL6Timestamp(tomorrow.format(oldPattern));
		dto.setL6DeployStatus("SUCCESS");
		dto.setL6TestStatus("PASS");
		dto.setL6Approval("Pravin Parbat (OSV)");
		dto.setL6Deployment("Pravin Parbat (OSV)");
		dto.setL6TestPass(10);
		dto.setL6TestFail(0);
		dto.setL6TestNotrun(0);
		dto.setL6TestTotal(10);
		dto.setL6AvgResponseTime(90);
		return dto;
	}


	
	public DevOpsDto genObjHsValidation(int count) {
		DevOpsDto dto =  new DevOpsDto();
		dto.setServiceName("HsValidationService");
		dto.setEai(3531592);
		dto.setStartedBy("Pravin Parbat (OSV)");
		dto.setIsLoadMaster("Pravin Parbat (OSV)");
		dto.setBuildNumber(count);
		dto.setEnvironment("L1");
		dto.setArtifact("hsvalidationservice2020.6."+count);
		ZonedDateTime tomorrow = ZonedDateTime.now().minusDays(100).plusDays(count);
		dto.setTimestamp(tomorrow.format(oldPattern));
		dto.setFindMergeRequests("false");
		dto.setBranch("HsValidationService-1.0-RELEASE");
		dto.setRevision("777c11f4ec269508fb974ab72831a325e40b9b2a"+count);
		dto.setBuild("SUCCESS");
		dto.setProjectKey("hsvalidationservice-3531592");
		dto.setSonarProjUrl("https://sonar.prod.cloud.fedex.com:9443/dashboard?id=hsvalidationservice-3531592");
		dto.setSonarUrl("https://sonar.prod.cloud.fedex.com:9443");
		dto.setNexusUrl("https://nexus.prod.cloud.fedex.com:8443/nexus/repository/");
		dto.setQualityGate("Red (was Green)");
		dto.setNcloc(count);
		dto.setComplexity(count);
		dto.setBugs(getRandomNumberInRange(count, count+1));
		dto.setNewBugs(getRandomNumberInRange(count, count+1));
		dto.setVulnerabilities(getRandomNumberInRange(count, count+1));
		dto.setNewVulnerabilities(getRandomNumberInRange(count, count+1));
		dto.setSMELLDEBT(getRandomNumberInRange(count, count+1));
		dto.setNewTechnicalDebt(getRandomNumberInRange(count, count+1));
		dto.setCodeSmell(getRandomNumberInRange(count, count+1));
		dto.setNewCodeSmell(getRandomNumberInRange(count, count+1));
		dto.setDuplicatedLinesDensity(new Double(count));
		dto.setDuplicatedBlocks(getRandomNumberInRange(count, count+1));
		dto.setNewDuplicatedBlocks(getRandomNumberInRange(count, count+1));
		dto.setCoverage(new Double(count));
		dto.setFortifyTotal(count*4);
		dto.setFortifyCritical(count);
		dto.setFortifyHigh(count);
		dto.setFortifyLow(count);
		dto.setFortifyMedium(count);
		dto.setL1Approval("Pravin Parbat (OSV)");
		dto.setL1Deployment("Pravin Parbat (OSV)");
		dto.setL1TestPass(10);
		dto.setL1TestFail(0);
		dto.setL1TestNotrun(0);
		dto.setL1TestTotal(10);
		dto.setL1AvgResponseTime(new Double(count));
		dto.setL2Approval("Pravin Parbat (OSV)");
		dto.setL2Deployment("Pravin Parbat (OSV)");
		dto.setL2TestPass(10);
		dto.setL2TestFail(0);
		dto.setL2TestNotrun(0);
		dto.setL2TestTotal(10);
		dto.setL2AvgResponseTime(new Double(count));
		dto.setL3Approval("Pravin Parbat (OSV)");
		dto.setL3Deployment("Pravin Parbat (OSV)");
		dto.setL3TestPass(10);
		dto.setL3TestFail(0);
		dto.setL3TestNotrun(0);
		dto.setL3TestTotal(10);
		dto.setL3AvgResponseTime(new Double(count));
		dto.setL4Approval("Pravin Parbat (OSV)");
		dto.setL4Deployment("Pravin Parbat (OSV)");
		dto.setL4TestPass(10);
		dto.setL4TestFail(0);
		dto.setL4TestNotrun(0);
		dto.setL4TestTotal(10);
		dto.setL4AvgResponseTime(new Double(count));
		dto.setL6Approval("Pravin Parbat (OSV)");
		dto.setL6Deployment("Pravin Parbat (OSV)");
		dto.setL6TestPass(10);
		dto.setL6TestFail(0);
		dto.setL6TestNotrun(0);
		dto.setL6TestTotal(10);
		dto.setL6AvgResponseTime(new Double(count));
		return dto;
	}
	private static int getRandomNumberInRange(int min, int max) {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}

		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}
	
}
