package com.sample.model;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class DevOpsDtoGen {
	
	//static String pattern = "yyyy-MM-dd.HH-mm-ss";
	static String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSSSSZ";
	static DateTimeFormatter oldPattern = DateTimeFormatter.ofPattern(pattern);
	
	
	public DevOpsDto genObj(int count, String servicenName) {
		DevOpsDto dto =  new DevOpsDto();
		dto.setServiceName(servicenName);
		dto.setEai(3531590);
		dto.setStartedBy("Pravin Parbat (OSV)");
		dto.setIsLoadMaster("Pravin Parbat (OSV)");
		dto.setBuildNumber(count);
		dto.setEnvironment("L1");
		dto.setArtifact(servicenName+"-2020.6."+count);
		ZonedDateTime tomorrow = ZonedDateTime.now().minusDays(100).plusDays(count);
		dto.setTimestamp(tomorrow.format(oldPattern));
		dto.setFindMergeRequests("false");
		dto.setBranch(servicenName+"-1.0-RELEASE");
		dto.setRevision("777c11f4ec269508fb974ab72831a325e40b9b2a"+count);
		dto.setBuild("SUCCESS");
		dto.setProjectKey(servicenName+"-3531590");
		dto.setSonarProjUrl("https://sonar.prod.cloud.fedex.com:9443/dashboard?id=edtdetaillookupservice-3531590");
		dto.setSonarUrl("https://sonar.prod.cloud.fedex.com:9443");
		dto.setNexusUrl("https://nexus.prod.cloud.fedex.com:8443/nexus/repository/");
		dto.setQualityGate("Red (was Green)");
		dto.setNcloc(2834 + count);
		dto.setComplexity(90);
		dto.setBugs(getRandomNumberInRange(count, count+1));
		dto.setNewBugs(getRandomNumberInRange(count, count+1));
		dto.setVulnerabilities(getRandomNumberInRange(count, count+1));
		dto.setNewVulnerabilities(getRandomNumberInRange(count, count+1));
		dto.setSMELLDEBT(getRandomNumberInRange(count, count+1));
		dto.setNewTechnicalDebt(getRandomNumberInRange(count, count+1));
		dto.setCodeSmell(getRandomNumberInRange(count, count+1));
		dto.setNewCodeSmell(getRandomNumberInRange(count, count+1));
		dto.setDuplicatedLinesDensity(new Double(count));
		dto.setDuplicatedBlocks(getRandomNumberInRange(count, count+1));
		dto.setNewDuplicatedBlocks(getRandomNumberInRange(count, count+1));
		dto.setCoverage(20d);
		dto.setFortifyTotal(count*4);
		dto.setFortifyCritical(count);
		dto.setFortifyHigh(count);
		dto.setFortifyLow(count);
		dto.setFortifyMedium(count);
		dto.setL1Approval("Pravin Parbat (OSV)");
		dto.setL1Deployment("Pravin Parbat (OSV)");
		dto.setL1TestPass(7);
		dto.setL1TestFail(2);
		dto.setL1TestNotrun(1);
		dto.setL1TestTotal(10);
		dto.setL1AvgResponseTime(485d);
		dto.setL2Approval("Pravin Parbat (OSV)");
		dto.setL2Deployment("Pravin Parbat (OSV)");
		dto.setL2TestPass(6);
		dto.setL2TestFail(1);
		dto.setL2TestNotrun(3);
		dto.setL2TestTotal(10);
		dto.setL2AvgResponseTime(480d);
		dto.setL3Approval("Pravin Parbat (OSV)");
		dto.setL3Deployment("Pravin Parbat (OSV)");
		dto.setL3TestPass(5);
		dto.setL3TestFail(5);
		dto.setL3TestNotrun(0);
		dto.setL3TestTotal(10);
		dto.setL3AvgResponseTime(380d);
		dto.setL4Approval("Pravin Parbat (OSV)");
		dto.setL4Deployment("Pravin Parbat (OSV)");
		dto.setL4TestPass(3);
		dto.setL4TestFail(5);
		dto.setL4TestNotrun(2);
		dto.setL4TestTotal(10);
		dto.setL4AvgResponseTime(240d);
		dto.setL6Approval("Pravin Parbat (OSV)");
		dto.setL6Deployment("Pravin Parbat (OSV)");
		dto.setL6TestPass(10);
		dto.setL6TestFail(0);
		dto.setL6TestNotrun(0);
		dto.setL6TestTotal(10);
		dto.setL6AvgResponseTime(300d);
		return dto;
	}


	public DevOpsDto genObjEdtDetailsLookup(int count) {
		DevOpsDto dto =  new DevOpsDto();
		dto.setServiceName("EdtDetailLookupService");
		dto.setEai(3531590);
		dto.setStartedBy("Pravin Parbat (OSV)");
		dto.setIsLoadMaster("Pravin Parbat (OSV)");
		dto.setBuildNumber(count);
		dto.setEnvironment("L1");
		dto.setArtifact("edt-detail-lookup-service-2020.6."+count);
		ZonedDateTime tomorrow = ZonedDateTime.now().minusDays(100).plusDays(count);
		dto.setTimestamp(tomorrow.format(oldPattern));
		dto.setFindMergeRequests("false");
		dto.setBranch("EdtDetailLookup-1.0-RELEASE");
		dto.setRevision("777c11f4ec269508fb974ab72831a325e40b9b2a"+count);
		dto.setBuild("SUCCESS");
		dto.setProjectKey("edtdetaillookupservice-3531590");
		dto.setSonarProjUrl("https://sonar.prod.cloud.fedex.com:9443/dashboard?id=edtdetaillookupservice-3531590");
		dto.setSonarUrl("https://sonar.prod.cloud.fedex.com:9443");
		dto.setNexusUrl("https://nexus.prod.cloud.fedex.com:8443/nexus/repository/");
		dto.setQualityGate("Red (was Green)");
		dto.setNcloc(count);
		dto.setComplexity(count);
		dto.setBugs(getRandomNumberInRange(count, count+1));
		dto.setNewBugs(getRandomNumberInRange(count, count+1));
		dto.setVulnerabilities(getRandomNumberInRange(count, count+1));
		dto.setNewVulnerabilities(getRandomNumberInRange(count, count+1));
		dto.setSMELLDEBT(getRandomNumberInRange(count, count+1));
		dto.setNewTechnicalDebt(getRandomNumberInRange(count, count+1));
		dto.setCodeSmell(getRandomNumberInRange(count, count+1));
		dto.setNewCodeSmell(getRandomNumberInRange(count, count+1));
		dto.setDuplicatedLinesDensity(new Double(count));
		dto.setDuplicatedBlocks(getRandomNumberInRange(count, count+1));
		dto.setNewDuplicatedBlocks(getRandomNumberInRange(count, count+1));
		dto.setCoverage(new Double(count));
		dto.setFortifyTotal(count*4);
		dto.setFortifyCritical(count);
		dto.setFortifyHigh(count);
		dto.setFortifyLow(count);
		dto.setFortifyMedium(count);
		dto.setL1Approval("Pravin Parbat (OSV)");
		dto.setL1Deployment("Pravin Parbat (OSV)");
		dto.setL1TestPass(10);
		dto.setL1TestFail(0);
		dto.setL1TestNotrun(0);
		dto.setL1TestTotal(10);
		dto.setL1AvgResponseTime(new Double(count));
		dto.setL2Approval("Pravin Parbat (OSV)");
		dto.setL2Deployment("Pravin Parbat (OSV)");
		dto.setL2TestPass(10);
		dto.setL2TestFail(0);
		dto.setL2TestNotrun(0);
		dto.setL2TestTotal(10);
		dto.setL2AvgResponseTime(new Double(count));
		dto.setL3Approval("Pravin Parbat (OSV)");
		dto.setL3Deployment("Pravin Parbat (OSV)");
		dto.setL3TestPass(10);
		dto.setL3TestFail(0);
		dto.setL3TestNotrun(0);
		dto.setL3TestTotal(10);
		dto.setL3AvgResponseTime(new Double(count));
		dto.setL4Approval("Pravin Parbat (OSV)");
		dto.setL4Deployment("Pravin Parbat (OSV)");
		dto.setL4TestPass(10);
		dto.setL4TestFail(0);
		dto.setL4TestNotrun(0);
		dto.setL4TestTotal(10);
		dto.setL4AvgResponseTime(new Double(count));
		dto.setL6Approval("Pravin Parbat (OSV)");
		dto.setL6Deployment("Pravin Parbat (OSV)");
		dto.setL6TestPass(10);
		dto.setL6TestFail(0);
		dto.setL6TestNotrun(0);
		dto.setL6TestTotal(10);
		dto.setL6AvgResponseTime(new Double(count));
		return dto;
	}
	
	public DevOpsDto genObjHsValidation(int count) {
		DevOpsDto dto =  new DevOpsDto();
		dto.setServiceName("HsValidationService");
		dto.setEai(3531592);
		dto.setStartedBy("Pravin Parbat (OSV)");
		dto.setIsLoadMaster("Pravin Parbat (OSV)");
		dto.setBuildNumber(count);
		dto.setEnvironment("L1");
		dto.setArtifact("hsvalidationservice2020.6."+count);
		ZonedDateTime tomorrow = ZonedDateTime.now().minusDays(100).plusDays(count);
		dto.setTimestamp(tomorrow.format(oldPattern));
		dto.setFindMergeRequests("false");
		dto.setBranch("HsValidationService-1.0-RELEASE");
		dto.setRevision("777c11f4ec269508fb974ab72831a325e40b9b2a"+count);
		dto.setBuild("SUCCESS");
		dto.setProjectKey("hsvalidationservice-3531592");
		dto.setSonarProjUrl("https://sonar.prod.cloud.fedex.com:9443/dashboard?id=hsvalidationservice-3531592");
		dto.setSonarUrl("https://sonar.prod.cloud.fedex.com:9443");
		dto.setNexusUrl("https://nexus.prod.cloud.fedex.com:8443/nexus/repository/");
		dto.setQualityGate("Red (was Green)");
		dto.setNcloc(count);
		dto.setComplexity(count);
		dto.setBugs(getRandomNumberInRange(count, count+1));
		dto.setNewBugs(getRandomNumberInRange(count, count+1));
		dto.setVulnerabilities(getRandomNumberInRange(count, count+1));
		dto.setNewVulnerabilities(getRandomNumberInRange(count, count+1));
		dto.setSMELLDEBT(getRandomNumberInRange(count, count+1));
		dto.setNewTechnicalDebt(getRandomNumberInRange(count, count+1));
		dto.setCodeSmell(getRandomNumberInRange(count, count+1));
		dto.setNewCodeSmell(getRandomNumberInRange(count, count+1));
		dto.setDuplicatedLinesDensity(new Double(count));
		dto.setDuplicatedBlocks(getRandomNumberInRange(count, count+1));
		dto.setNewDuplicatedBlocks(getRandomNumberInRange(count, count+1));
		dto.setCoverage(new Double(count));
		dto.setFortifyTotal(count*4);
		dto.setFortifyCritical(count);
		dto.setFortifyHigh(count);
		dto.setFortifyLow(count);
		dto.setFortifyMedium(count);
		dto.setL1Approval("Pravin Parbat (OSV)");
		dto.setL1Deployment("Pravin Parbat (OSV)");
		dto.setL1TestPass(10);
		dto.setL1TestFail(0);
		dto.setL1TestNotrun(0);
		dto.setL1TestTotal(10);
		dto.setL1AvgResponseTime(new Double(count));
		dto.setL2Approval("Pravin Parbat (OSV)");
		dto.setL2Deployment("Pravin Parbat (OSV)");
		dto.setL2TestPass(10);
		dto.setL2TestFail(0);
		dto.setL2TestNotrun(0);
		dto.setL2TestTotal(10);
		dto.setL2AvgResponseTime(new Double(count));
		dto.setL3Approval("Pravin Parbat (OSV)");
		dto.setL3Deployment("Pravin Parbat (OSV)");
		dto.setL3TestPass(10);
		dto.setL3TestFail(0);
		dto.setL3TestNotrun(0);
		dto.setL3TestTotal(10);
		dto.setL3AvgResponseTime(new Double(count));
		dto.setL4Approval("Pravin Parbat (OSV)");
		dto.setL4Deployment("Pravin Parbat (OSV)");
		dto.setL4TestPass(10);
		dto.setL4TestFail(0);
		dto.setL4TestNotrun(0);
		dto.setL4TestTotal(10);
		dto.setL4AvgResponseTime(new Double(count));
		dto.setL6Approval("Pravin Parbat (OSV)");
		dto.setL6Deployment("Pravin Parbat (OSV)");
		dto.setL6TestPass(10);
		dto.setL6TestFail(0);
		dto.setL6TestNotrun(0);
		dto.setL6TestTotal(10);
		dto.setL6AvgResponseTime(new Double(count));
		return dto;
	}
	private static int getRandomNumberInRange(int min, int max) {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}

		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}
	
}
