package com.sample.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "service_name",
    "domain",
    "eai",
    "started_by",
    "is_load_master",
    "build_number",
    "build_type",
    "environment",
    "artifact",
    "timestamp",
    "find_merge_requests",
    "branch",
    "revision",
    "build",
    "project_key",
    "sonar_proj_url",
    "sonar_url",
    "nexus_url",
    "quality_gate",
    "ncloc",
    "complexity",
    "bugs",
    "new_bugs",
    "vulnerabilities",
    "new_vulnerabilities",
    "SMELL_DEBT",
    "new_technical_debt",
    "code_smell",
    "new_code_smell",
    "duplicated_lines_density",
    "duplicated_blocks",
    "new_duplicated_blocks",
    "coverage",
    "fortify_total",
    "fortify_critical",
    "fortify_high",
    "fortify_medium",
    "fortify_low",
    "l1_env",
    "l1_started_by",
    "l1_load_master",
    "l1_build_number",
    "l1_timestamp",
    "l1_deploy_status",
    "l1_test_status",
    "l1_approval",
    "l1_deployment",
    "l1_test_pass",
    "l1_test_fail",
    "l1_test_notrun",
    "l1_test_total",
    "l1_avg_response_time",
    "l2_env",
    "l2_started_by",
    "l2_load_master",
    "l2_build_number",
    "l2_timestamp",
    "l2_deploy_status",
    "l2_test_status",
    "l2_approval",
    "l2_deployment",
    "l2_test_pass",
    "l2_test_fail",
    "l2_test_notrun",
    "l2_test_total",
    "l2_avg_response_time",
    "l3_env",
    "l3_started_by",
    "l3_load_master",
    "l3_build_number",
    "l3_timestamp",
    "l3_deploy_status",
    "l3_test_status",
    "l3_approval",
    "l3_deployment",
    "l3_test_pass",
    "l3_test_fail",
    "l3_test_notrun",
    "l3_test_total",
    "l3_avg_response_time",
    "l4_env",
    "l4_started_by",
    "l4_load_master",
    "l4_build_number",
    "l4_timestamp",
    "l4_deploy_status",
    "l4_test_status",
    "l4_approval",
    "l4_deployment",
    "l4_test_pass",
    "l4_test_fail",
    "l4_test_notrun",
    "l4_test_total",
    "l4_avg_response_time",
    "l6_env",
    "l6_started_by",
    "l6_load_master",
    "l6_build_number",
    "l6_timestamp",
    "l6_deploy_status",
    "l6_test_status",
    "l6_approval",
    "l6_deployment",
    "l6_test_pass",
    "l6_test_fail",
    "l6_test_notrun",
    "l6_test_total",
    "l6_avg_response_time"
})
public class DashBoardVo {

    @JsonProperty("service_name")
    private String serviceName;
    @JsonProperty("domain")
    private String domain;
    @JsonProperty("eai")
    private Integer eai;
    @JsonProperty("started_by")
    private String startedBy;
    @JsonProperty("is_load_master")
    private String isLoadMaster;
    @JsonProperty("build_number")
    private Integer buildNumber;
    @JsonProperty("build_type")
    private String buildType;
    @JsonProperty("environment")
    private String environment;
    @JsonProperty("artifact")
    private String artifact;
    @JsonProperty("timestamp")
    private String timestamp;
    @JsonProperty("find_merge_requests")
    private String findMergeRequests;
    @JsonProperty("branch")
    private String branch;
    @JsonProperty("revision")
    private String revision;
    @JsonProperty("build")
    private String build;
    @JsonProperty("project_key")
    private String projectKey;
    @JsonProperty("sonar_proj_url")
    private String sonarProjUrl;
    @JsonProperty("sonar_url")
    private String sonarUrl;
    @JsonProperty("nexus_url")
    private String nexusUrl;
    @JsonProperty("quality_gate")
    private String qualityGate;
    @JsonProperty("ncloc")
    private Integer ncloc;
    @JsonProperty("complexity")
    private Integer complexity;
    @JsonProperty("bugs")
    private Integer bugs;
    @JsonProperty("new_bugs")
    private Integer newBugs;
    @JsonProperty("vulnerabilities")
    private Integer vulnerabilities;
    @JsonProperty("new_vulnerabilities")
    private Integer newVulnerabilities;
    @JsonProperty("SMELL_DEBT")
    private Integer sMELLDEBT;
    @JsonProperty("new_technical_debt")
    private Integer newTechnicalDebt;
    @JsonProperty("code_smell")
    private Integer codeSmell;
    @JsonProperty("new_code_smell")
    private Integer newCodeSmell;
    @JsonProperty("duplicated_lines_density")
    private Double duplicatedLinesDensity;
    @JsonProperty("duplicated_blocks")
    private Integer duplicatedBlocks;
    @JsonProperty("new_duplicated_blocks")
    private Integer newDuplicatedBlocks;
    @JsonProperty("coverage")
    private Double coverage;
    @JsonProperty("fortify_total")
    private Integer fortifyTotal;
    @JsonProperty("fortify_critical")
    private Integer fortifyCritical;
    @JsonProperty("fortify_high")
    private Integer fortifyHigh;
    @JsonProperty("fortify_medium")
    private Integer fortifyMedium;
    @JsonProperty("fortify_low")
    private Integer fortifyLow;
    @JsonProperty("l1_env")
    private String l1Env;
    @JsonProperty("l1_started_by")
    private String l1StartedBy;
    @JsonProperty("l1_load_master")
    private String l1LoadMaster;
    @JsonProperty("l1_build_number")
    private Integer l1BuildNumber;
    @JsonProperty("l1_timestamp")
    private String l1Timestamp;
    @JsonProperty("l1_deploy_status")
    private String l1DeployStatus;
    @JsonProperty("l1_test_status")
    private String l1TestStatus;
    @JsonProperty("l1_approval")
    private String l1Approval;
    @JsonProperty("l1_deployment")
    private String l1Deployment;
    @JsonProperty("l1_test_pass")
    private Integer l1TestPass;
    @JsonProperty("l1_test_fail")
    private Integer l1TestFail;
    @JsonProperty("l1_test_notrun")
    private Integer l1TestNotrun;
    @JsonProperty("l1_test_total")
    private Integer l1TestTotal;
    @JsonProperty("l1_avg_response_time")
    private Integer l1AvgResponseTime;
    @JsonProperty("l2_env")
    private String l2Env;
    @JsonProperty("l2_started_by")
    private String l2StartedBy;
    @JsonProperty("l2_load_master")
    private String l2LoadMaster;
    @JsonProperty("l2_build_number")
    private Integer l2BuildNumber;
    @JsonProperty("l2_timestamp")
    private String l2Timestamp;
    @JsonProperty("l2_deploy_status")
    private String l2DeployStatus;
    @JsonProperty("l2_test_status")
    private String l2TestStatus;
    @JsonProperty("l2_approval")
    private String l2Approval;
    @JsonProperty("l2_deployment")
    private String l2Deployment;
    @JsonProperty("l2_test_pass")
    private Integer l2TestPass;
    @JsonProperty("l2_test_fail")
    private Integer l2TestFail;
    @JsonProperty("l2_test_notrun")
    private Integer l2TestNotrun;
    @JsonProperty("l2_test_total")
    private Integer l2TestTotal;
    @JsonProperty("l2_avg_response_time")
    private Integer l2AvgResponseTime;
    @JsonProperty("l3_env")
    private String l3Env;
    @JsonProperty("l3_started_by")
    private String l3StartedBy;
    @JsonProperty("l3_load_master")
    private String l3LoadMaster;
    @JsonProperty("l3_build_number")
    private Integer l3BuildNumber;
    @JsonProperty("l3_timestamp")
    private String l3Timestamp;
    @JsonProperty("l3_deploy_status")
    private String l3DeployStatus;
    @JsonProperty("l3_test_status")
    private String l3TestStatus;
    @JsonProperty("l3_approval")
    private String l3Approval;
    @JsonProperty("l3_deployment")
    private String l3Deployment;
    @JsonProperty("l3_test_pass")
    private Integer l3TestPass;
    @JsonProperty("l3_test_fail")
    private Integer l3TestFail;
    @JsonProperty("l3_test_notrun")
    private Integer l3TestNotrun;
    @JsonProperty("l3_test_total")
    private Integer l3TestTotal;
    @JsonProperty("l3_avg_response_time")
    private Integer l3AvgResponseTime;
    @JsonProperty("l4_env")
    private String l4Env;
    @JsonProperty("l4_started_by")
    private String l4StartedBy;
    @JsonProperty("l4_load_master")
    private String l4LoadMaster;
    @JsonProperty("l4_build_number")
    private Integer l4BuildNumber;
    @JsonProperty("l4_timestamp")
    private String l4Timestamp;
    @JsonProperty("l4_deploy_status")
    private String l4DeployStatus;
    @JsonProperty("l4_test_status")
    private String l4TestStatus;
    @JsonProperty("l4_approval")
    private String l4Approval;
    @JsonProperty("l4_deployment")
    private String l4Deployment;
    @JsonProperty("l4_test_pass")
    private Integer l4TestPass;
    @JsonProperty("l4_test_fail")
    private Integer l4TestFail;
    @JsonProperty("l4_test_notrun")
    private Integer l4TestNotrun;
    @JsonProperty("l4_test_total")
    private Integer l4TestTotal;
    @JsonProperty("l4_avg_response_time")
    private Integer l4AvgResponseTime;
    @JsonProperty("l6_env")
    private String l6Env;
    @JsonProperty("l6_started_by")
    private String l6StartedBy;
    @JsonProperty("l6_load_master")
    private String l6LoadMaster;
    @JsonProperty("l6_build_number")
    private Integer l6BuildNumber;
    @JsonProperty("l6_timestamp")
    private String l6Timestamp;
    @JsonProperty("l6_deploy_status")
    private String l6DeployStatus;
    @JsonProperty("l6_test_status")
    private String l6TestStatus;
    @JsonProperty("l6_approval")
    private String l6Approval;
    @JsonProperty("l6_deployment")
    private String l6Deployment;
    @JsonProperty("l6_test_pass")
    private Integer l6TestPass;
    @JsonProperty("l6_test_fail")
    private Integer l6TestFail;
    @JsonProperty("l6_test_notrun")
    private Integer l6TestNotrun;
    @JsonProperty("l6_test_total")
    private Integer l6TestTotal;
    @JsonProperty("l6_avg_response_time")
    private Integer l6AvgResponseTime;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("service_name")
    public String getServiceName() {
        return serviceName;
    }

    @JsonProperty("service_name")
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    @JsonProperty("domain")
    public String getDomain() {
        return domain;
    }

    @JsonProperty("domain")
    public void setDomain(String domain) {
        this.domain = domain;
    }

    @JsonProperty("eai")
    public Integer getEai() {
        return eai;
    }

    @JsonProperty("eai")
    public void setEai(Integer eai) {
        this.eai = eai;
    }

    @JsonProperty("started_by")
    public String getStartedBy() {
        return startedBy;
    }

    @JsonProperty("started_by")
    public void setStartedBy(String startedBy) {
        this.startedBy = startedBy;
    }

    @JsonProperty("is_load_master")
    public String getIsLoadMaster() {
        return isLoadMaster;
    }

    @JsonProperty("is_load_master")
    public void setIsLoadMaster(String isLoadMaster) {
        this.isLoadMaster = isLoadMaster;
    }

    @JsonProperty("build_number")
    public Integer getBuildNumber() {
        return buildNumber;
    }

    @JsonProperty("build_number")
    public void setBuildNumber(Integer buildNumber) {
        this.buildNumber = buildNumber;
    }

    @JsonProperty("build_type")
    public String getBuildType() {
        return buildType;
    }

    @JsonProperty("build_type")
    public void setBuildType(String buildType) {
        this.buildType = buildType;
    }

    @JsonProperty("environment")
    public String getEnvironment() {
        return environment;
    }

    @JsonProperty("environment")
    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    @JsonProperty("artifact")
    public String getArtifact() {
        return artifact;
    }

    @JsonProperty("artifact")
    public void setArtifact(String artifact) {
        this.artifact = artifact;
    }

    @JsonProperty("timestamp")
    public String getTimestamp() {
        return timestamp;
    }

    @JsonProperty("timestamp")
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    @JsonProperty("find_merge_requests")
    public String getFindMergeRequests() {
        return findMergeRequests;
    }

    @JsonProperty("find_merge_requests")
    public void setFindMergeRequests(String findMergeRequests) {
        this.findMergeRequests = findMergeRequests;
    }

    @JsonProperty("branch")
    public String getBranch() {
        return branch;
    }

    @JsonProperty("branch")
    public void setBranch(String branch) {
        this.branch = branch;
    }

    @JsonProperty("revision")
    public String getRevision() {
        return revision;
    }

    @JsonProperty("revision")
    public void setRevision(String revision) {
        this.revision = revision;
    }

    @JsonProperty("build")
    public String getBuild() {
        return build;
    }

    @JsonProperty("build")
    public void setBuild(String build) {
        this.build = build;
    }

    @JsonProperty("project_key")
    public String getProjectKey() {
        return projectKey;
    }

    @JsonProperty("project_key")
    public void setProjectKey(String projectKey) {
        this.projectKey = projectKey;
    }

    @JsonProperty("sonar_proj_url")
    public String getSonarProjUrl() {
        return sonarProjUrl;
    }

    @JsonProperty("sonar_proj_url")
    public void setSonarProjUrl(String sonarProjUrl) {
        this.sonarProjUrl = sonarProjUrl;
    }

    @JsonProperty("sonar_url")
    public String getSonarUrl() {
        return sonarUrl;
    }

    @JsonProperty("sonar_url")
    public void setSonarUrl(String sonarUrl) {
        this.sonarUrl = sonarUrl;
    }

    @JsonProperty("nexus_url")
    public String getNexusUrl() {
        return nexusUrl;
    }

    @JsonProperty("nexus_url")
    public void setNexusUrl(String nexusUrl) {
        this.nexusUrl = nexusUrl;
    }

    @JsonProperty("quality_gate")
    public String getQualityGate() {
        return qualityGate;
    }

    @JsonProperty("quality_gate")
    public void setQualityGate(String qualityGate) {
        this.qualityGate = qualityGate;
    }

    @JsonProperty("ncloc")
    public Integer getNcloc() {
        return ncloc;
    }

    @JsonProperty("ncloc")
    public void setNcloc(Integer ncloc) {
        this.ncloc = ncloc;
    }

    @JsonProperty("complexity")
    public Integer getComplexity() {
        return complexity;
    }

    @JsonProperty("complexity")
    public void setComplexity(Integer complexity) {
        this.complexity = complexity;
    }

    @JsonProperty("bugs")
    public Integer getBugs() {
        return bugs;
    }

    @JsonProperty("bugs")
    public void setBugs(Integer bugs) {
        this.bugs = bugs;
    }

    @JsonProperty("new_bugs")
    public Integer getNewBugs() {
        return newBugs;
    }

    @JsonProperty("new_bugs")
    public void setNewBugs(Integer newBugs) {
        this.newBugs = newBugs;
    }

    @JsonProperty("vulnerabilities")
    public Integer getVulnerabilities() {
        return vulnerabilities;
    }

    @JsonProperty("vulnerabilities")
    public void setVulnerabilities(Integer vulnerabilities) {
        this.vulnerabilities = vulnerabilities;
    }

    @JsonProperty("new_vulnerabilities")
    public Integer getNewVulnerabilities() {
        return newVulnerabilities;
    }

    @JsonProperty("new_vulnerabilities")
    public void setNewVulnerabilities(Integer newVulnerabilities) {
        this.newVulnerabilities = newVulnerabilities;
    }

    @JsonProperty("SMELL_DEBT")
    public Integer getSMELLDEBT() {
        return sMELLDEBT;
    }

    @JsonProperty("SMELL_DEBT")
    public void setSMELLDEBT(Integer sMELLDEBT) {
        this.sMELLDEBT = sMELLDEBT;
    }

    @JsonProperty("new_technical_debt")
    public Integer getNewTechnicalDebt() {
        return newTechnicalDebt;
    }

    @JsonProperty("new_technical_debt")
    public void setNewTechnicalDebt(Integer newTechnicalDebt) {
        this.newTechnicalDebt = newTechnicalDebt;
    }

    @JsonProperty("code_smell")
    public Integer getCodeSmell() {
        return codeSmell;
    }

    @JsonProperty("code_smell")
    public void setCodeSmell(Integer codeSmell) {
        this.codeSmell = codeSmell;
    }

    @JsonProperty("new_code_smell")
    public Integer getNewCodeSmell() {
        return newCodeSmell;
    }

    @JsonProperty("new_code_smell")
    public void setNewCodeSmell(Integer newCodeSmell) {
        this.newCodeSmell = newCodeSmell;
    }

    @JsonProperty("duplicated_lines_density")
    public Double getDuplicatedLinesDensity() {
        return duplicatedLinesDensity;
    }

    @JsonProperty("duplicated_lines_density")
    public void setDuplicatedLinesDensity(Double duplicatedLinesDensity) {
        this.duplicatedLinesDensity = duplicatedLinesDensity;
    }

    @JsonProperty("duplicated_blocks")
    public Integer getDuplicatedBlocks() {
        return duplicatedBlocks;
    }

    @JsonProperty("duplicated_blocks")
    public void setDuplicatedBlocks(Integer duplicatedBlocks) {
        this.duplicatedBlocks = duplicatedBlocks;
    }

    @JsonProperty("new_duplicated_blocks")
    public Integer getNewDuplicatedBlocks() {
        return newDuplicatedBlocks;
    }

    @JsonProperty("new_duplicated_blocks")
    public void setNewDuplicatedBlocks(Integer newDuplicatedBlocks) {
        this.newDuplicatedBlocks = newDuplicatedBlocks;
    }

    @JsonProperty("coverage")
    public Double getCoverage() {
        return coverage;
    }

    @JsonProperty("coverage")
    public void setCoverage(Double coverage) {
        this.coverage = coverage;
    }

    @JsonProperty("fortify_total")
    public Integer getFortifyTotal() {
        return fortifyTotal;
    }

    @JsonProperty("fortify_total")
    public void setFortifyTotal(Integer fortifyTotal) {
        this.fortifyTotal = fortifyTotal;
    }

    @JsonProperty("fortify_critical")
    public Integer getFortifyCritical() {
        return fortifyCritical;
    }

    @JsonProperty("fortify_critical")
    public void setFortifyCritical(Integer fortifyCritical) {
        this.fortifyCritical = fortifyCritical;
    }

    @JsonProperty("fortify_high")
    public Integer getFortifyHigh() {
        return fortifyHigh;
    }

    @JsonProperty("fortify_high")
    public void setFortifyHigh(Integer fortifyHigh) {
        this.fortifyHigh = fortifyHigh;
    }

    @JsonProperty("fortify_medium")
    public Integer getFortifyMedium() {
        return fortifyMedium;
    }

    @JsonProperty("fortify_medium")
    public void setFortifyMedium(Integer fortifyMedium) {
        this.fortifyMedium = fortifyMedium;
    }

    @JsonProperty("fortify_low")
    public Integer getFortifyLow() {
        return fortifyLow;
    }

    @JsonProperty("fortify_low")
    public void setFortifyLow(Integer fortifyLow) {
        this.fortifyLow = fortifyLow;
    }

    @JsonProperty("l1_env")
    public String getL1Env() {
        return l1Env;
    }

    @JsonProperty("l1_env")
    public void setL1Env(String l1Env) {
        this.l1Env = l1Env;
    }

    @JsonProperty("l1_started_by")
    public String getL1StartedBy() {
        return l1StartedBy;
    }

    @JsonProperty("l1_started_by")
    public void setL1StartedBy(String l1StartedBy) {
        this.l1StartedBy = l1StartedBy;
    }

    @JsonProperty("l1_load_master")
    public String getL1LoadMaster() {
        return l1LoadMaster;
    }

    @JsonProperty("l1_load_master")
    public void setL1LoadMaster(String l1LoadMaster) {
        this.l1LoadMaster = l1LoadMaster;
    }

    @JsonProperty("l1_build_number")
    public Integer getL1BuildNumber() {
        return l1BuildNumber;
    }

    @JsonProperty("l1_build_number")
    public void setL1BuildNumber(Integer l1BuildNumber) {
        this.l1BuildNumber = l1BuildNumber;
    }

    @JsonProperty("l1_timestamp")
    public String getL1Timestamp() {
        return l1Timestamp;
    }

    @JsonProperty("l1_timestamp")
    public void setL1Timestamp(String l1Timestamp) {
        this.l1Timestamp = l1Timestamp;
    }

    @JsonProperty("l1_deploy_status")
    public String getL1DeployStatus() {
        return l1DeployStatus;
    }

    @JsonProperty("l1_deploy_status")
    public void setL1DeployStatus(String l1DeployStatus) {
        this.l1DeployStatus = l1DeployStatus;
    }

    @JsonProperty("l1_test_status")
    public String getL1TestStatus() {
        return l1TestStatus;
    }

    @JsonProperty("l1_test_status")
    public void setL1TestStatus(String l1TestStatus) {
        this.l1TestStatus = l1TestStatus;
    }

    @JsonProperty("l1_approval")
    public String getL1Approval() {
        return l1Approval;
    }

    @JsonProperty("l1_approval")
    public void setL1Approval(String l1Approval) {
        this.l1Approval = l1Approval;
    }

    @JsonProperty("l1_deployment")
    public String getL1Deployment() {
        return l1Deployment;
    }

    @JsonProperty("l1_deployment")
    public void setL1Deployment(String l1Deployment) {
        this.l1Deployment = l1Deployment;
    }

    @JsonProperty("l1_test_pass")
    public Integer getL1TestPass() {
        return l1TestPass;
    }

    @JsonProperty("l1_test_pass")
    public void setL1TestPass(Integer l1TestPass) {
        this.l1TestPass = l1TestPass;
    }

    @JsonProperty("l1_test_fail")
    public Integer getL1TestFail() {
        return l1TestFail;
    }

    @JsonProperty("l1_test_fail")
    public void setL1TestFail(Integer l1TestFail) {
        this.l1TestFail = l1TestFail;
    }

    @JsonProperty("l1_test_notrun")
    public Integer getL1TestNotrun() {
        return l1TestNotrun;
    }

    @JsonProperty("l1_test_notrun")
    public void setL1TestNotrun(Integer l1TestNotrun) {
        this.l1TestNotrun = l1TestNotrun;
    }

    @JsonProperty("l1_test_total")
    public Integer getL1TestTotal() {
        return l1TestTotal;
    }

    @JsonProperty("l1_test_total")
    public void setL1TestTotal(Integer l1TestTotal) {
        this.l1TestTotal = l1TestTotal;
    }

    @JsonProperty("l1_avg_response_time")
    public Integer getL1AvgResponseTime() {
        return l1AvgResponseTime;
    }

    @JsonProperty("l1_avg_response_time")
    public void setL1AvgResponseTime(Integer l1AvgResponseTime) {
        this.l1AvgResponseTime = l1AvgResponseTime;
    }

    @JsonProperty("l2_env")
    public String getL2Env() {
        return l2Env;
    }

    @JsonProperty("l2_env")
    public void setL2Env(String l2Env) {
        this.l2Env = l2Env;
    }

    @JsonProperty("l2_started_by")
    public String getL2StartedBy() {
        return l2StartedBy;
    }

    @JsonProperty("l2_started_by")
    public void setL2StartedBy(String l2StartedBy) {
        this.l2StartedBy = l2StartedBy;
    }

    @JsonProperty("l2_load_master")
    public String getL2LoadMaster() {
        return l2LoadMaster;
    }

    @JsonProperty("l2_load_master")
    public void setL2LoadMaster(String l2LoadMaster) {
        this.l2LoadMaster = l2LoadMaster;
    }

    @JsonProperty("l2_build_number")
    public Integer getL2BuildNumber() {
        return l2BuildNumber;
    }

    @JsonProperty("l2_build_number")
    public void setL2BuildNumber(Integer l2BuildNumber) {
        this.l2BuildNumber = l2BuildNumber;
    }

    @JsonProperty("l2_timestamp")
    public String getL2Timestamp() {
        return l2Timestamp;
    }

    @JsonProperty("l2_timestamp")
    public void setL2Timestamp(String l2Timestamp) {
        this.l2Timestamp = l2Timestamp;
    }

    @JsonProperty("l2_deploy_status")
    public String getL2DeployStatus() {
        return l2DeployStatus;
    }

    @JsonProperty("l2_deploy_status")
    public void setL2DeployStatus(String l2DeployStatus) {
        this.l2DeployStatus = l2DeployStatus;
    }

    @JsonProperty("l2_test_status")
    public String getL2TestStatus() {
        return l2TestStatus;
    }

    @JsonProperty("l2_test_status")
    public void setL2TestStatus(String l2TestStatus) {
        this.l2TestStatus = l2TestStatus;
    }

    @JsonProperty("l2_approval")
    public String getL2Approval() {
        return l2Approval;
    }

    @JsonProperty("l2_approval")
    public void setL2Approval(String l2Approval) {
        this.l2Approval = l2Approval;
    }

    @JsonProperty("l2_deployment")
    public String getL2Deployment() {
        return l2Deployment;
    }

    @JsonProperty("l2_deployment")
    public void setL2Deployment(String l2Deployment) {
        this.l2Deployment = l2Deployment;
    }

    @JsonProperty("l2_test_pass")
    public Integer getL2TestPass() {
        return l2TestPass;
    }

    @JsonProperty("l2_test_pass")
    public void setL2TestPass(Integer l2TestPass) {
        this.l2TestPass = l2TestPass;
    }

    @JsonProperty("l2_test_fail")
    public Integer getL2TestFail() {
        return l2TestFail;
    }

    @JsonProperty("l2_test_fail")
    public void setL2TestFail(Integer l2TestFail) {
        this.l2TestFail = l2TestFail;
    }

    @JsonProperty("l2_test_notrun")
    public Integer getL2TestNotrun() {
        return l2TestNotrun;
    }

    @JsonProperty("l2_test_notrun")
    public void setL2TestNotrun(Integer l2TestNotrun) {
        this.l2TestNotrun = l2TestNotrun;
    }

    @JsonProperty("l2_test_total")
    public Integer getL2TestTotal() {
        return l2TestTotal;
    }

    @JsonProperty("l2_test_total")
    public void setL2TestTotal(Integer l2TestTotal) {
        this.l2TestTotal = l2TestTotal;
    }

    @JsonProperty("l2_avg_response_time")
    public Integer getL2AvgResponseTime() {
        return l2AvgResponseTime;
    }

    @JsonProperty("l2_avg_response_time")
    public void setL2AvgResponseTime(Integer l2AvgResponseTime) {
        this.l2AvgResponseTime = l2AvgResponseTime;
    }

    @JsonProperty("l3_env")
    public String getL3Env() {
        return l3Env;
    }

    @JsonProperty("l3_env")
    public void setL3Env(String l3Env) {
        this.l3Env = l3Env;
    }

    @JsonProperty("l3_started_by")
    public String getL3StartedBy() {
        return l3StartedBy;
    }

    @JsonProperty("l3_started_by")
    public void setL3StartedBy(String l3StartedBy) {
        this.l3StartedBy = l3StartedBy;
    }

    @JsonProperty("l3_load_master")
    public String getL3LoadMaster() {
        return l3LoadMaster;
    }

    @JsonProperty("l3_load_master")
    public void setL3LoadMaster(String l3LoadMaster) {
        this.l3LoadMaster = l3LoadMaster;
    }

    @JsonProperty("l3_build_number")
    public Integer getL3BuildNumber() {
        return l3BuildNumber;
    }

    @JsonProperty("l3_build_number")
    public void setL3BuildNumber(Integer l3BuildNumber) {
        this.l3BuildNumber = l3BuildNumber;
    }

    @JsonProperty("l3_timestamp")
    public String getL3Timestamp() {
        return l3Timestamp;
    }

    @JsonProperty("l3_timestamp")
    public void setL3Timestamp(String l3Timestamp) {
        this.l3Timestamp = l3Timestamp;
    }

    @JsonProperty("l3_deploy_status")
    public String getL3DeployStatus() {
        return l3DeployStatus;
    }

    @JsonProperty("l3_deploy_status")
    public void setL3DeployStatus(String l3DeployStatus) {
        this.l3DeployStatus = l3DeployStatus;
    }

    @JsonProperty("l3_test_status")
    public String getL3TestStatus() {
        return l3TestStatus;
    }

    @JsonProperty("l3_test_status")
    public void setL3TestStatus(String l3TestStatus) {
        this.l3TestStatus = l3TestStatus;
    }

    @JsonProperty("l3_approval")
    public String getL3Approval() {
        return l3Approval;
    }

    @JsonProperty("l3_approval")
    public void setL3Approval(String l3Approval) {
        this.l3Approval = l3Approval;
    }

    @JsonProperty("l3_deployment")
    public String getL3Deployment() {
        return l3Deployment;
    }

    @JsonProperty("l3_deployment")
    public void setL3Deployment(String l3Deployment) {
        this.l3Deployment = l3Deployment;
    }

    @JsonProperty("l3_test_pass")
    public Integer getL3TestPass() {
        return l3TestPass;
    }

    @JsonProperty("l3_test_pass")
    public void setL3TestPass(Integer l3TestPass) {
        this.l3TestPass = l3TestPass;
    }

    @JsonProperty("l3_test_fail")
    public Integer getL3TestFail() {
        return l3TestFail;
    }

    @JsonProperty("l3_test_fail")
    public void setL3TestFail(Integer l3TestFail) {
        this.l3TestFail = l3TestFail;
    }

    @JsonProperty("l3_test_notrun")
    public Integer getL3TestNotrun() {
        return l3TestNotrun;
    }

    @JsonProperty("l3_test_notrun")
    public void setL3TestNotrun(Integer l3TestNotrun) {
        this.l3TestNotrun = l3TestNotrun;
    }

    @JsonProperty("l3_test_total")
    public Integer getL3TestTotal() {
        return l3TestTotal;
    }

    @JsonProperty("l3_test_total")
    public void setL3TestTotal(Integer l3TestTotal) {
        this.l3TestTotal = l3TestTotal;
    }

    @JsonProperty("l3_avg_response_time")
    public Integer getL3AvgResponseTime() {
        return l3AvgResponseTime;
    }

    @JsonProperty("l3_avg_response_time")
    public void setL3AvgResponseTime(Integer l3AvgResponseTime) {
        this.l3AvgResponseTime = l3AvgResponseTime;
    }

    @JsonProperty("l4_env")
    public String getL4Env() {
        return l4Env;
    }

    @JsonProperty("l4_env")
    public void setL4Env(String l4Env) {
        this.l4Env = l4Env;
    }

    @JsonProperty("l4_started_by")
    public String getL4StartedBy() {
        return l4StartedBy;
    }

    @JsonProperty("l4_started_by")
    public void setL4StartedBy(String l4StartedBy) {
        this.l4StartedBy = l4StartedBy;
    }

    @JsonProperty("l4_load_master")
    public String getL4LoadMaster() {
        return l4LoadMaster;
    }

    @JsonProperty("l4_load_master")
    public void setL4LoadMaster(String l4LoadMaster) {
        this.l4LoadMaster = l4LoadMaster;
    }

    @JsonProperty("l4_build_number")
    public Integer getL4BuildNumber() {
        return l4BuildNumber;
    }

    @JsonProperty("l4_build_number")
    public void setL4BuildNumber(Integer l4BuildNumber) {
        this.l4BuildNumber = l4BuildNumber;
    }

    @JsonProperty("l4_timestamp")
    public String getL4Timestamp() {
        return l4Timestamp;
    }

    @JsonProperty("l4_timestamp")
    public void setL4Timestamp(String l4Timestamp) {
        this.l4Timestamp = l4Timestamp;
    }

    @JsonProperty("l4_deploy_status")
    public String getL4DeployStatus() {
        return l4DeployStatus;
    }

    @JsonProperty("l4_deploy_status")
    public void setL4DeployStatus(String l4DeployStatus) {
        this.l4DeployStatus = l4DeployStatus;
    }

    @JsonProperty("l4_test_status")
    public String getL4TestStatus() {
        return l4TestStatus;
    }

    @JsonProperty("l4_test_status")
    public void setL4TestStatus(String l4TestStatus) {
        this.l4TestStatus = l4TestStatus;
    }

    @JsonProperty("l4_approval")
    public String getL4Approval() {
        return l4Approval;
    }

    @JsonProperty("l4_approval")
    public void setL4Approval(String l4Approval) {
        this.l4Approval = l4Approval;
    }

    @JsonProperty("l4_deployment")
    public String getL4Deployment() {
        return l4Deployment;
    }

    @JsonProperty("l4_deployment")
    public void setL4Deployment(String l4Deployment) {
        this.l4Deployment = l4Deployment;
    }

    @JsonProperty("l4_test_pass")
    public Integer getL4TestPass() {
        return l4TestPass;
    }

    @JsonProperty("l4_test_pass")
    public void setL4TestPass(Integer l4TestPass) {
        this.l4TestPass = l4TestPass;
    }

    @JsonProperty("l4_test_fail")
    public Integer getL4TestFail() {
        return l4TestFail;
    }

    @JsonProperty("l4_test_fail")
    public void setL4TestFail(Integer l4TestFail) {
        this.l4TestFail = l4TestFail;
    }

    @JsonProperty("l4_test_notrun")
    public Integer getL4TestNotrun() {
        return l4TestNotrun;
    }

    @JsonProperty("l4_test_notrun")
    public void setL4TestNotrun(Integer l4TestNotrun) {
        this.l4TestNotrun = l4TestNotrun;
    }

    @JsonProperty("l4_test_total")
    public Integer getL4TestTotal() {
        return l4TestTotal;
    }

    @JsonProperty("l4_test_total")
    public void setL4TestTotal(Integer l4TestTotal) {
        this.l4TestTotal = l4TestTotal;
    }

    @JsonProperty("l4_avg_response_time")
    public Integer getL4AvgResponseTime() {
        return l4AvgResponseTime;
    }

    @JsonProperty("l4_avg_response_time")
    public void setL4AvgResponseTime(Integer l4AvgResponseTime) {
        this.l4AvgResponseTime = l4AvgResponseTime;
    }

    @JsonProperty("l6_env")
    public String getL6Env() {
        return l6Env;
    }

    @JsonProperty("l6_env")
    public void setL6Env(String l6Env) {
        this.l6Env = l6Env;
    }

    @JsonProperty("l6_started_by")
    public String getL6StartedBy() {
        return l6StartedBy;
    }

    @JsonProperty("l6_started_by")
    public void setL6StartedBy(String l6StartedBy) {
        this.l6StartedBy = l6StartedBy;
    }

    @JsonProperty("l6_load_master")
    public String getL6LoadMaster() {
        return l6LoadMaster;
    }

    @JsonProperty("l6_load_master")
    public void setL6LoadMaster(String l6LoadMaster) {
        this.l6LoadMaster = l6LoadMaster;
    }

    @JsonProperty("l6_build_number")
    public Integer getL6BuildNumber() {
        return l6BuildNumber;
    }

    @JsonProperty("l6_build_number")
    public void setL6BuildNumber(Integer l6BuildNumber) {
        this.l6BuildNumber = l6BuildNumber;
    }

    @JsonProperty("l6_timestamp")
    public String getL6Timestamp() {
        return l6Timestamp;
    }

    @JsonProperty("l6_timestamp")
    public void setL6Timestamp(String l6Timestamp) {
        this.l6Timestamp = l6Timestamp;
    }

    @JsonProperty("l6_deploy_status")
    public String getL6DeployStatus() {
        return l6DeployStatus;
    }

    @JsonProperty("l6_deploy_status")
    public void setL6DeployStatus(String l6DeployStatus) {
        this.l6DeployStatus = l6DeployStatus;
    }

    @JsonProperty("l6_test_status")
    public String getL6TestStatus() {
        return l6TestStatus;
    }

    @JsonProperty("l6_test_status")
    public void setL6TestStatus(String l6TestStatus) {
        this.l6TestStatus = l6TestStatus;
    }

    @JsonProperty("l6_approval")
    public String getL6Approval() {
        return l6Approval;
    }

    @JsonProperty("l6_approval")
    public void setL6Approval(String l6Approval) {
        this.l6Approval = l6Approval;
    }

    @JsonProperty("l6_deployment")
    public String getL6Deployment() {
        return l6Deployment;
    }

    @JsonProperty("l6_deployment")
    public void setL6Deployment(String l6Deployment) {
        this.l6Deployment = l6Deployment;
    }

    @JsonProperty("l6_test_pass")
    public Integer getL6TestPass() {
        return l6TestPass;
    }

    @JsonProperty("l6_test_pass")
    public void setL6TestPass(Integer l6TestPass) {
        this.l6TestPass = l6TestPass;
    }

    @JsonProperty("l6_test_fail")
    public Integer getL6TestFail() {
        return l6TestFail;
    }

    @JsonProperty("l6_test_fail")
    public void setL6TestFail(Integer l6TestFail) {
        this.l6TestFail = l6TestFail;
    }

    @JsonProperty("l6_test_notrun")
    public Integer getL6TestNotrun() {
        return l6TestNotrun;
    }

    @JsonProperty("l6_test_notrun")
    public void setL6TestNotrun(Integer l6TestNotrun) {
        this.l6TestNotrun = l6TestNotrun;
    }

    @JsonProperty("l6_test_total")
    public Integer getL6TestTotal() {
        return l6TestTotal;
    }

    @JsonProperty("l6_test_total")
    public void setL6TestTotal(Integer l6TestTotal) {
        this.l6TestTotal = l6TestTotal;
    }

    @JsonProperty("l6_avg_response_time")
    public Integer getL6AvgResponseTime() {
        return l6AvgResponseTime;
    }

    @JsonProperty("l6_avg_response_time")
    public void setL6AvgResponseTime(Integer l6AvgResponseTime) {
        this.l6AvgResponseTime = l6AvgResponseTime;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
